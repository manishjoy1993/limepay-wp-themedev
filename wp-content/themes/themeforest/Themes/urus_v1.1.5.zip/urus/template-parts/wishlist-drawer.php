<?php
?>
<div id="Familab_WishlistDrawer" class="wishlist-drawer drawer">
    <div class="wrapper">
        <div class="wishlist-header">
            <div class="js-close-wishlist"> <?php echo familab_icons('close'); ?> </div>
            <div class="title"><?php esc_html_e('Wishlist', 'urus'); ?></div>
            <div class="wishlist-count">0</div>
        </div>
       <div class="wishlist-inner">

       </div>
    </div>
</div>
