<?php
/**
 * Template Name: Grid Blog
 *
 * 
 * @package    Auxin
 * @author     averta (c) 2014-2018
 * @link       http://averta.net
 */

locate_template( 'templates/blog-main.php', true );
