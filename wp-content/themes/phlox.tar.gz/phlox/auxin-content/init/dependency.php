<?php
/**
 * Dependency Credentials
 */
if( ! defined('AUXELS_REQUIRED_VERSION') ) define( 'AUXELS_REQUIRED_VERSION', '2.3.2' );
if( ! defined('AUXPFO_REQUIRED_VERSION') ) define( 'AUXPFO_REQUIRED_VERSION', '1.7.6' );
