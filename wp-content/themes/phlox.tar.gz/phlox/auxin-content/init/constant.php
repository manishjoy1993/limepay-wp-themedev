<?php
/**
 * Defining Constants.
 *
 * 
 * @package    Auxin
 * @author     averta (c) 2014-2018
 * @link       http://averta.net
 */

/*-----------------------------------------------------------------------------------*/
/*  Define Global Vars
/*-----------------------------------------------------------------------------------*/

// theme name
$theme_data = wp_get_theme();

// this id is used as prefix in database option field names - specific for each theme
if( ! defined('THEME_ID' )       ) define( 'THEME_ID'        ,  'phlox' );
if( ! defined('THEME'.'_DOMAIN') ) define( 'THEME'.'_DOMAIN' ,  'phlox' );

if( ! defined('THEME_NAME')      ) define( 'THEME_NAME'      , esc_attr( $theme_data->Name ) );

if( ! defined('THEME_NAME_I18N') ) define( 'THEME_NAME_I18N' , esc_attr__( 'Phlox', 'phlox' ) );
if( ! defined('THEME_PRO_NAME_I18N') ) define( 'THEME_PRO_NAME_I18N' , esc_attr__( 'Phlox Pro', 'phlox' ) );


// dummy gettext call to translate theme name
__( 'PHLOX', 'phlox' );

/*-----------------------------------------------------------------------------------*/
