<div class="wrap">
    <h2><?php _e( 'Search themes on justfreethemes.com', 'jft-assistant' ); ?></h2>

	<div class="jft-search-bar">
		<input type="text" class="medium-text" name="jft-theme" id="jft-theme" placeholder="<?php _e( 'Search themes on justfreethemes.com', 'jft-assistant' ); ?> ...">
	</div>

	<div id="jft-search-results">
	</div>
</div>
